<div style="width:25%;height:95vh;position:fixed;margin-top:53px;" class="bg-secondary ">
<ul class="nav flex-column doom">
  <li class="nav-item">
    <a class="nav-link text-white" href="manage_course.php">Manage Courses</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white" href="manage_quiz.php">Manage Quiz</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white" href="manage_video.php">Manage Videos</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white" href="view_comments.php">view Comments</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white" href="view_users.php">Manage Users</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white" href="logout.php">Logout</a>
  </li>
</ul>
</div>