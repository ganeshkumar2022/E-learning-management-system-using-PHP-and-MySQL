<nav>
<ul class="nav justify-content-center p-4 bg-primary">
  <li class="nav-item" style="margin-top:-7px;">
    <a class="nav-link text-white font-weight-bold" href="#"><b style="font-size:25px;font-family:verdana;">E-Learning System</b></a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white font-weight-bold" href="#"></a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white font-weight-bold" href="#"></a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white font-weight-bold" href="editprofile.php">Edit Profile</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white font-weight-bold" href="start_quiz.php">Start Quiz</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-white font-weight-bold btn roun" href="logout.php" style="">Logout</a>
  </li>
</ul>
</nav>